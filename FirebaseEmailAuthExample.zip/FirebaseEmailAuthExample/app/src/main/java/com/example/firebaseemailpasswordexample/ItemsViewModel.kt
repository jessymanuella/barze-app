package com.example.firebaseemailpasswordexample

data class ItemsViewModel(val text: String, val bar: String) {
}