package com.example.firebaseemailpasswordexample

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Button
import android.widget.ImageView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.firebaseemailpasswordexample.databinding.ActivityMainBinding
import com.example.firebaseemailpasswordexample.databinding.PostFragmentBinding
import com.google.firebase.auth.FirebaseAuth

class PostFragment : AppCompatActivity() {

    private lateinit var binding: PostFragmentBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val data = ArrayList<ItemsViewModel>()

        binding = PostFragmentBinding.inflate(layoutInflater)

        val email: String = binding.Info.text.toString()
        val password: String = binding.name.text.toString()

        binding.postBtn.setOnClickListener {

        }




    }
}