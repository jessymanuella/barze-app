package com.example.firebaseemailpasswordexample

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.firebaseemailpasswordexample.databinding.ActivityMainBinding

class FeedActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val data = ArrayList<ItemsViewModel>()

        binding = ActivityMainBinding.inflate(layoutInflater)


        // getting the recyclerview by its id
        val recyclerview = findViewById<RecyclerView>(R.id.recyclerview)

        // this creates a vertical layout Manager
        recyclerview.layoutManager = LinearLayoutManager(this)



        // This loop will create 20 Views containing
        // the image with the count of view

        //1
        data.add(ItemsViewModel("Bentley's DJ has been playing miley cyrus for 30 minutes","Samantha"))
        //2
        data.add(ItemsViewModel("Someone is trying to bring their dog to CStone","Cole"))
        //1
        data.add(ItemsViewModel("You guys should be understanding how recycler views are implemented","A. Porter"))
        //1
        data.add(ItemsViewModel("$4 drinks at Cstone if you're wearing cowprint","Leah"))
        //1
        data.add(ItemsViewModel("Guys, can we shower before we go to the bars? it smells terrible","Colleen"))
        //1
        data.add(ItemsViewModel("I prothmis3 i''me naugtaht drnk","Wilmer"))
        //1
        data.add(ItemsViewModel("If i hear one more pitbbull song...","Bobby"))
        //1
        data.add(ItemsViewModel("I never thought I'd need an app to tell me the best place to get drunk at ","Onyeka"))
        //1
        data.add(ItemsViewModel("Turf's smells like you guys have been studying for a hard exam","O. James"))
        //1
        data.add(ItemsViewModel("LOOOONEEYYYYYSSSSSSSSSSS","Your mom"))
        //1
        data.add(ItemsViewModel("just ran into my ex. Where to next?","Robert"))


        // This will pass the ArrayList to our Adapter
        val adapter = CustomAdapter(data)

        // Setting the Adapter with the recyclerview
        recyclerview.adapter = adapter

    }
}