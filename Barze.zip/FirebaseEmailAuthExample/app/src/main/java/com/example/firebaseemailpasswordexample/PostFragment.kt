package com.example.firebaseemailpasswordexample

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.firebaseemailpasswordexample.databinding.PostFragmentBinding

class PostFragment : AppCompatActivity() {

    private lateinit var binding: PostFragmentBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.post_fragment)

        val data = ArrayList<ItemsViewModel>()

        binding = PostFragmentBinding.inflate(layoutInflater)

        val email: String = binding.Info.text.toString()
        val password: String = binding.name.text.toString()

        binding.postBtn.setOnClickListener {

        }




    }
}