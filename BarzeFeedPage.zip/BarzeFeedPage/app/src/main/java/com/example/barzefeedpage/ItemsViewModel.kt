package com.example.barzefeedpage

data class ItemsViewModel(val text: String, val bar: String) {
}
